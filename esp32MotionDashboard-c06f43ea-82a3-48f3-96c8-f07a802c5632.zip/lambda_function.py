import boto3
import json
from decimal import Decimal

dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("MotionEvents")


def fix_decimal(obj):
    if isinstance(obj, list):
        return [fix_decimal(i) for i in obj]
    if isinstance(obj, dict):
        return {k: fix_decimal(v) for k, v in obj.items()}
    if isinstance(obj, Decimal):
        return float(obj)
    return obj


def cors_headers():
    return {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET,OPTIONS",
        "Access-Control-Allow-Headers": "*",
    }


def lambda_handler(event, context):
    print("=== esp32MotionDashboard invoked ===")
    print("Dashboard event:", json.dumps(event))

    # Handle CORS preflight from the browser
    if event.get("httpMethod") == "OPTIONS":
        return {
            "statusCode": 200,
            "headers": cors_headers(),
            "body": ""
        }

    # Normal GET: read from DynamoDB
    response = table.scan()
    items = response.get("Items", [])
    items = sorted(items, key=lambda x: x.get("timestamp", 0), reverse=True)
    items = fix_decimal(items)

    print(f"Returning {len(items)} items to dashboard")

    return {
        "statusCode": 200,
        "headers": cors_headers(),
        "body": json.dumps(items)
    }
