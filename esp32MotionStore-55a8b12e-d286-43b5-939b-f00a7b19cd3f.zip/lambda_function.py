import json
import time
import uuid
from decimal import Decimal

import boto3

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('MotionEvents')

sns = boto3.client('sns')
SNS_TOPIC_ARN = "arn:aws:sns:us-east-2:975350718328:motionAlerts"

def lambda_handler(event, context):
    print("=== esp32MotionStore invoked ===")
    print("Raw event:")
    print(json.dumps(event, indent=2))

    # ---------- 1. Extract diff and motion from any possible place ----------
    diff_str = None
    motion_str = None

    # a) API Gateway proxy: query string
    qs = event.get("queryStringParameters") or {}
    if isinstance(qs, dict):
        diff_str = qs.get("diff", diff_str)
        motion_str = qs.get("motion", motion_str)

    # b) Top-level fields (in case of direct invoke tests)
    diff_str = event.get("diff", diff_str)
    motion_str = event.get("motion", motion_str)

    # c) JSON body (for POST with JSON)
    body = event.get("body")
    if body:
        try:
            if isinstance(body, str):
                body_json = json.loads(body)
            else:
                body_json = body

            if isinstance(body_json, dict):
                diff_str = body_json.get("diff", diff_str)
                motion_str = body_json.get("motion", motion_str)
        except Exception as e:
            print("Could not parse body as JSON:", e)

    # ---------- 2. Convert to numeric, with safe fallbacks ----------
    try:
        diff = float(diff_str) if diff_str is not None else 0.0
    except Exception as e:
        print("Error converting diff:", e)
        diff = 0.0

    try:
        motion = int(motion_str) if motion_str is not None else 0
    except Exception as e:
        print("Error converting motion:", e)
        motion = 0

    print(f"Parsed diff={diff}, motion={motion}")

    # ---------- 3. Store in DynamoDB ----------
    try:
        item = {
            "eventId": str(uuid.uuid4()),
            "timestamp": int(time.time()),
            "diff": Decimal(str(diff)),   # DynamoDB wants Decimal, not float
            "motion": motion
        }

        table.put_item(Item=item)
        print("Stored item in DynamoDB:", item)

        # 🔔 SNS ALERT LOGIC
        if motion == 1 and diff > 2.0:
            msg = f"Motion detected! diff={diff:.2f}, motion={motion}, eventId={item['eventId']}"
            print("Publishing SNS alert:", msg)
            try:
                resp = sns.publish(
                    TopicArn=SNS_TOPIC_ARN,
                    Subject="ESP32 Motion Alert",
                    Message=msg,
                )
                print("SNS publish response:", resp)
            except Exception as e:
                print("Error publishing to SNS:", e)

    except Exception as e:
        print("Error writing to DynamoDB:", e)
        return {
            "statusCode": 500,
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps({
                "message": "Failed to store motion event",
                "error": str(e)
            })
        }

    # ---------- 4. Success response ----------
    return {
        "statusCode": 200,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps({
            "message": "Stored motion event and sent alert if needed",
            "stored": True,
            "diff": diff,
            "motion": motion
        })
    }
